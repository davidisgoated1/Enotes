from django.shortcuts import render, redirect
from .models import User, Signup, Notes
from django.contrib.auth import authenticate, logout, login

# Create your views here.

def index(request):
    return render(request, 'index.html')

def about(request):
    return render(request, 'about.html')

def register(request):
    error = ""
    if request.method == 'POST':
        fn = request.POST.get('firstName')
        ln = request.POST.get('lastName')
        e = request.POST.get('email')
        p = request.POST.get('password')
        c = request.POST.get('ContactNo')
        ab = request.POST.get('About')
        role = "ROLE_USER"

        try:
            user = User.objects.create_user(username=e, password=p, first_name=fn, last_name=ln)
            Signup.objects.create(user=user, ContactNo=c, About=ab, Role=role)
            error = "no"
        except Exception as ex:
            print(ex)  # Logging the exception can help debug
            error = "yes"

    return render(request, 'register.html', {'error': error})

def user_login(request):
    error = ""
    if request.method == 'POST':
        u = request.POST.get('email')
        p = request.POST.get('password')
        user = authenticate(username=u, password=p)

        if user is not None:
            login(request, user)
            error = "no"
        else:
            error = "yes"

    return render(request, 'user_login.html', {'error': error})

def dashboard(request):
    if not request.user.is_authenticated:
        return redirect('user_login')

    user = request.user
    signup = Signup.objects.get(user=user)
    totalnotes = Notes.objects.filter(signup=signup).count()

    return render(request, 'dashboard.html', {'totalnotes': totalnotes})

def profile(request):
    if not request.user.is_authenticated:
        return redirect('user_login')

    user = request.user
    signup = Signup.objects.get(user=user)

    if request.method == "POST":
        fname = request.POST.get('firstName')
        lname = request.POST.get('lastName')
        contactNo = request.POST.get('ContactNo')
        about = request.POST.get('About')

        signup.user.first_name = fname
        signup.user.last_name = lname
        signup.ContactNo = contactNo
        signup.About = about

        try:
            signup.user.save()
            signup.save()
            error = "no"
        except Exception as ex:
            print(ex)
            error = "yes"

    return render(request, 'profile.html', {'signup': signup})

def addNotes(request):
    if not request.user.is_authenticated:
        return redirect('user_login')

    user = request.user
    signup = Signup.objects.get(user=user)
    error = ""

    if request.method == "POST":
        title = request.POST.get('Title')
        content = request.POST.get('Content')

        try:
            Notes.objects.create(signup=signup, Title=title, Content=content)
            error = "no"
        except Exception as ex:
            print(ex)
            error = "yes"

    return render(request, 'addNotes.html', {'error': error})

def viewNotes(request):
    if not request.user.is_authenticated:
        return redirect('user_login')

    user = request.user
    signup = Signup.objects.get(user=user)
    notes = Notes.objects.filter(signup=signup)

    return render(request, 'viewNotes.html', {'notes': notes})

def editNotes(request, pid):
    if not request.user.is_authenticated:
        return redirect('user_login')

    notes = Notes.objects.get(id=pid)
    error = ""

    if request.method == "POST":
        title = request.POST.get('Title')
        content = request.POST.get('Content')

        notes.Title = title
        notes.Content = content

        try:
            notes.save()
            error = "no"
        except Exception as ex:
            print(ex)
            error = "yes"

    return render(request, 'editNotes.html', {'notes': notes, 'error': error})

def deleteNotes(request, pid):
    if not request.user.is_authenticated:
        return redirect('user_login')

    notes = Notes.objects.get(id=pid)
    notes.delete()
    return redirect('viewNotes')

def changePassword(request):
    if not request.user.is_authenticated:
        return redirect('user_login')

    error = ""
    user = request.user

    if request.method == "POST":
        o = request.POST.get('oldpassword')
        n = request.POST.get('newpassword')

        if user.check_password(o):
            user.set_password(n)
            user.save()
            error = "no"
        else:
            error = 'not'

    return render(request, 'changePassword.html', {'error': error})

def Logout(request):
    logout(request)
    return redirect('index')
